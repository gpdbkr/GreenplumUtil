alias sa='cd /home/gpadmin/user/shlee/sa'
