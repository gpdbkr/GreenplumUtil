## statlog(7 days)
/usr/bin/find /data/dba/utilities/statlog -mtime +7 -print -exec mv -f {} /data/backup/statlog \;
