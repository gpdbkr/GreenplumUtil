#!/bin/sh

scp /data/master/gpseg-1/pg_hba.conf smdw:/data/master/gpseg-1/pg_hba.conf
scp /data/master/gpseg-1/postgresql.conf smdw:/data/master/gpseg-1/postgresql.conf
