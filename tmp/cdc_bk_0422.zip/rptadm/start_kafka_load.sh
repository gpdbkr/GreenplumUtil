if [ $# -lt 1 ] ; then
  echo $0 "jobname"
  exit
fi

#gpsscli start jstemplate --force-reset-latest
#gpsscli start $1 --force-reset-latest
#gpsscli start $1 $2
gpsscli start $1 --force-reset-earliest