psql -c "truncate table public.cdc_log ;" -d pocdb
psql -c "truncate table public.cdc_log_check ;" -d pocdb