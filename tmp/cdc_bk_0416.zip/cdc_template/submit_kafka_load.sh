# gpsscli submit --name jstemplate --gpss-port 5007 ~/pivotal/cdc/cdc_template/template_stg.yaml
# gpsscli submit --name jstemplate ~/pivotal/cdc/cdc_template/template_stg.yaml
# gpsscli submit --name jstemplate ~/pivotal/cdc/cdc_template/template_stg.yaml.striim
gpsscli submit --name jstemplate ~/pivotal/cdc/cdc_template/template_stg.yaml.template 
# gpsscli submit --name jstemplate ~/pivotal/cdc/cdc_template/template_stg.yaml.without
