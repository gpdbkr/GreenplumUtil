./stop_kafka_load.sh
./remove_kafka_load.sh 
./submit_kafka_load.sh 
./start_kafka_load.sh 
./list_kafka_load.sh
